const char *hello_string = "Hello world!";
