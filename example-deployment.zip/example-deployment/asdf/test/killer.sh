#!/bin/sh

kill $$
