#!/bin/sh

sh -c 'kill $$'
